package com.example.demo1;

import static android.app.PendingIntent.getActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText; // 用户名输入框
    private EditText passwordEditText; // 密码输入框
    private CheckBox rememberPasswordCheckBox; // 记住密码复选框
    private CheckBox autoLoginCheckBox; // 自动登录复选框
    private Button loginButton; // 登录按钮
    private Button registerButton; // 注册按钮

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_login); // 指定要运行的布局文件
        initView();
    }
    public void initView(){
        usernameEditText = findViewById(R.id.usernameEditText); // 查找用户名输入框
        passwordEditText = findViewById(R.id.passwordEditText); // 查找密码输入框
        rememberPasswordCheckBox = findViewById(R.id.rememberPasswordCheckBox); // 查找记住密码复选框
        autoLoginCheckBox = findViewById(R.id.autoLoginCheckBox); // 查找自动登录复选框
        loginButton = findViewById(R.id.loginButton); // 查找登录按钮
        registerButton = findViewById(R.id.registerButton); // 查找注册按钮

        loginButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String username = usernameEditText.getText().toString();  // 获取用户名
                String password = passwordEditText.getText().toString();  // 获取密码

                // 执行查询操作，检查用户名和密码是否匹配
                // 创建数据库助手对象
                MyOpenHelper myOpenHelper = new MyOpenHelper(getActivity());
                // 获取可读数据库
                SQLiteDatabase db = myOpenHelper.getReadableDatabase();
                // 执行查询操作
                Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});

                if (cursor.moveToFirst()) {
                    // 登录成功

                    // 创建一个Intent对象，用于跳转到PersonActivity
                    Intent intent = new Intent(getActivity(), PersonActivity.class);

                    // 在Intent中传递数据（可选）
                    intent.putExtra("username", username);

                    // 执行跳转
                    startActivity(intent);
                } else {
                    // 密码或账号错误时，显示提示信息并清空密码输入框
                    Toast.makeText(getActivity(), "用户名或密码错误", Toast.LENGTH_SHORT).show();
                    passwordEditText.setText("");
                }

                // 关闭游标和数据库连接
                cursor.close();
                db.close();
            }

            private Context getActivity() {
                return MainActivity.this;
            }

        });
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 创建一个Intent对象，用于跳转到注册页面（RegisterActivity）
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);

                // 执行跳转
                startActivity(intent);
            }
        });
    }
}
