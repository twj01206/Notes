package com.example.demo1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyOpenHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "database.db";
    private static final int DATABASE_VERSION = 1;

    public MyOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 创建表格的SQL语句
        String createTableQuery = "CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, phone TEXT, verificationCode TEXT, password TEXT)";
        // 执行创建表格的SQL语句
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 处理数据库升级的逻辑
        // 这里可以添加数据库升级时的操作，例如修改表格结构或迁移数据
    }

    public long insertUser(String username, String phone, String verificationCode, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("phone", phone);
        values.put("verificationCode", verificationCode);
        values.put("password", password);
        long insertedId = db.insert("users", null, values);
        db.close();
        return insertedId;
    }

    public void updateUser(int userId, String newUsername) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", newUsername);
        db.update("users", values, "id=?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public void deleteUser(int userId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("users", "id=?", new String[]{String.valueOf(userId)});
        db.close();
    }

    public Cursor getUsers() {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = {"id", "username", "phone", "verificationCode", "password"};
        Cursor cursor = db.query("users", columns, null, null, null, null, null);
        return cursor;
    }
}
