package com.example.demo1;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginActivity extends Fragment {
    private EditText usernameEditText;            // 用户名输入框
    private EditText passwordEditText;           // 密码输入框
    private CheckBox rememberPasswordCheckBox;   // 记住密码复选框
    private CheckBox autoLoginCheckBox;         // 自动登录复选框
    private Button loginButton;                 // 登录按钮
    private Button registerButton;              // 注册按钮

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //这是 onCreateView 方法，当片段被创建时会调用该方法。它使用提供的 inflater 将布局文件 fragment_login.xml 填充为一个 View 对象。
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // 通过ID查找视图  使用 findViewById 方法初始化成员变量，将其引用设置为填充视图中对应的 UI 元素。
        usernameEditText = view.findViewById(R.id.usernameEditText);                   // 查找用户名输入框
        passwordEditText = view.findViewById(R.id.passwordEditText);                   // 查找密码输入框
        rememberPasswordCheckBox = view.findViewById(R.id.rememberPasswordCheckBox);   // 查找记住密码复选框
        autoLoginCheckBox = view.findViewById(R.id.autoLoginCheckBox);                 // 查找自动登录复选框
        loginButton = view.findViewById(R.id.loginButton);                             // 查找登录按钮
        registerButton = view.findViewById(R.id.registerButton);                        // 查找注册按钮
        passwordEditText = view.findViewById(R.id.passwordEditText);  // 查找密码输入框
        loginButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String username = usernameEditText.getText().toString();  // 获取用户名
                String password = passwordEditText.getText().toString();  // 获取密码

                // 执行查询操作，检查用户名和密码是否匹配
                // 创建数据库助手对象
                MyOpenHelper myOpenHelper = new MyOpenHelper(getActivity());
                // 获取可读数据库
                SQLiteDatabase db = myOpenHelper.getReadableDatabase();
                // 执行查询操作
                Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});

                if (cursor.moveToFirst()) {
                    // 登录成功

                    // 创建一个Intent对象，用于跳转到PersonActivity
                    Intent intent = new Intent(getActivity(), PersonActivity.class);

                    // 在Intent中传递数据（可选）
                    intent.putExtra("username", username);

                    // 执行跳转
                    startActivity(intent);
                } else {
                    // 密码或账号错误时，显示提示信息并清空密码输入框
                    Toast.makeText(getActivity(), "用户名或密码错误", Toast.LENGTH_SHORT).show();
                    passwordEditText.setText("");
                }

                // 关闭游标和数据库连接
                cursor.close();
                db.close();
            }
        });
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 创建一个Intent对象，用于跳转到注册页面（RegisterActivity）
                Intent intent = new Intent(getActivity(), RegisterActivity.class);

                // 执行跳转
                startActivity(intent);
            }
        });

        return view;
    }
}
