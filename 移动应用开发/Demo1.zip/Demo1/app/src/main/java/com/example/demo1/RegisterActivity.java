package com.example.demo1;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPhone;
    private EditText editTextVerificationCode;
    private EditText editTextPassword;
    private CheckBox checkBoxAgree;
    private Button buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 通过ID找到视图
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextVerificationCode = findViewById(R.id.editTextVerificationCode);
        editTextPassword = findViewById(R.id.editTextPassword);
        checkBoxAgree = findViewById(R.id.checkBoxAgree);
        buttonRegister = findViewById(R.id.buttonRegister);

        // 为注册按钮设置点击监听器
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 调用registerUser方法处理用户注册
                registerUser();
            }
        });
    }

    private void registerUser() {
        // 从EditText字段获取输入值
        String username = editTextUsername.getText().toString().trim();
        String phone = editTextPhone.getText().toString().trim();
        String verificationCode = editTextVerificationCode.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        boolean agree = checkBoxAgree.isChecked();

        // 验证输入值（例如，检查空字段和格式）
        if (TextUtils.isEmpty(username) || username.length() < 3) {
            editTextUsername.setError("用户名至少为3个字符");
            editTextUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(phone) || phone.length() != 11) {
            editTextPhone.setError("手机号必须为11位");
            editTextPhone.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(verificationCode)) {
            editTextVerificationCode.setError("验证码不能为空");
            editTextVerificationCode.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 6) {
            editTextPassword.setError("密码至少为6位");
            editTextPassword.requestFocus();
            return;
        }

        if (!agree) {
            checkBoxAgree.setError("请同意条款和条件");
            checkBoxAgree.requestFocus();
            return;
        }

        // 在此处执行用户注册过程
        // 您可以进行API调用或将用户数据保存到数据库
        // 创建 MyOpenHelper 对象
        MyOpenHelper myOpenHelper = new MyOpenHelper(this);
        SQLiteDatabase db = myOpenHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("phone", phone);
        values.put("verificationCode", verificationCode);
        values.put("password", password);
        db.insert("users", null, values);
        db.close();

        // 显示成功消息或导航到另一个屏幕
        Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
