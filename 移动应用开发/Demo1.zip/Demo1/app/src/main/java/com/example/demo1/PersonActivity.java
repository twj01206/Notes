package com.example.demo1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class PersonActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_person);

        // 获取传递的数据
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");

        // 打印用户名信息
        if (username != null) {
            Log.d("PersonActivity", "Received username: " + username);
        }
    }
}
